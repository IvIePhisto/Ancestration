Ancestration – Family Inheritance for Python
============================================

This project implements the so-called *family inheritance* for Python 2 and 3.
It is based on the doctoral thesis of Patrick Lay "Entwurf eines Objektmodells
für semistrukturierte Daten im Kontext von XML Content Management Systemen"
(Rheinische Friedrich-Wilhelms Universität Bonn, 2006) and is developed as
part of the diploma thesis of Michael Pohl "Architektur und Implementierung
des Objektmodells für ein Web Application Framework" (Rheinische
Friedrich-Wilhelms Universität Bonn, 2013-2014).
